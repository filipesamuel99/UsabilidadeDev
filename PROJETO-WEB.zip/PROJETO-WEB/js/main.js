function verificarNumero() {

    let numero = document.querySelector("#numero").value;

    if (numero % 2 == 0)
        alert("Par");
    else
        alert("Impar");    
}